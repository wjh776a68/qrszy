/**************
 *
 *	Author: wenjiahao
 *	Date  : 2021-01-16
 *	Content: This File is PART of 2018218794-bubblesort.cpp
 *
 * **************/
#include<iostream>

using namespace std;

int chartoint(char* input){
	int i=0;
	int out=0;	
	while(*(input+i)!='\0'){
		out = 10 * out + *(input+i) - '0';
		i++;
	}
	
	return out;
}


