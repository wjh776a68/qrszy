
/**************
 *
 *	Author: wenjiahao
 *	Date  : 2021-01-16
 *	Content: This File is PART of 2018218794-bubblesort.cpp
 *
 * **************/
#ifndef CHARTOINT_H_
#define CHARTOINT_H_

int chartoint(char* input);


#endif
