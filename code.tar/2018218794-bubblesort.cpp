/******
 *	Author: wenjiahao
 *	Date  : 2021-01-16
 *	Content: Homework for ARM Lesson.
 *
 * *****/
#include <iostream>
#include <malloc.h>
#include "chartoint.h"
using namespace std;


int main(int argc,char* argv[]){
	
	int* intarray = (int*)malloc(sizeof(int) * argc);
	cout << "Bubble Sort\n2018218794\n";
	int i = 0;
	cout << "Before Sort:\t";
	for(i = 1;i < argc;i++){
			
		*(intarray+i) = chartoint(*(argv+i));
		cout << *(intarray+i) << "\t";
	}
	
	cout << "\n";
	
	int m,n,t;
	for(m=1;m<argc;m++)
		for(n=m;n<argc;n++){
			if(*(intarray+m)>*(intarray+n)){
				t=*(intarray+m);
				*(intarray+m)=*(intarray+n);
				*(intarray+n)=t;
			}
		}
	
	cout << "After Sort:\t";
	for(i=1; i < argc;i++)
		cout << *(intarray+i) << "\t";
	cout << "\n";
	return 0;
}


